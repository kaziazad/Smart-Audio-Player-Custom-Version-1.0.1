<?php
/**
 * Plugin Name:       Smart Audio Player Pro
 * Plugin URI:        https://kazimahmud.com/
 * Description:       Audio Player for Wordpress. 
 * Version:           1.0.2
 * Requires at least: 5.8
 * Requires PHP:      7.2
 * Author:            Web Solutions
 * Author URI:        https://kazimahmud.com/
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       kmaa-td
 * Domain Path:       /languages
 */

if ( ! defined( 'ABSPATH' ) ) {
   exit; // Exit if accessed directly
}

final class Kmaa_Audio_Filter {

   public function __construct() {
       add_action('wp_enqueue_scripts', array($this, 'kmaa_audio_filter_style'));
       add_action('rest_api_init', array($this, 'kmaa_audio_filter_rest_api'));

       
   }

   function kmaa_audio_filter_style() {
       
       wp_enqueue_style('kmaa-fontawesome', "https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css", __FILE__);
       wp_enqueue_style('kmaa-audio_customstyle', plugins_url('/css/style.css', __FILE__));
	   
	   wp_enqueue_script('jquery-afilter', "https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js", array(), '', true);
       wp_enqueue_script('kmaa-script-js', plugins_url('/js/scripts.js', __FILE__), array(), '', true);
   }

   public function shortcode(){
       add_shortcode('audio-filter',array($this,'audio_filter_function'));
       
   } 


   function kmaa_audio_filter_rest_api_callback(){
    $the_query = new WP_Query(array(
        'post_type' => 'music', 
        'post_status'=>'publish',
        'posts_per_page' => -1, 
    ));

    $data="sdsdsd";
    return new WP_REST_Response($data, 200);
   } 


   function kmaa_audio_filter_rest_api(){

    register_rest_route('custom/v1', '/data', array(
            'methods' => 'GET',
            'callback' => array($this, 'kmaa_audio_filter_rest_api_callback'),
            // 'permission_callback' => '__return_true'
        ));
   } 

   




   function audio_filter_function(){
     
       ob_start(); ?>
<style>
@media only screen and (min-width: 1024px) and (max-width:1359px){
						.music-style label {	
							width: 150px;
							
						}
						}
@media only screen and (min-width: 768px) and (max-width:1023px){
						.music-style label {	
							width: 23%;
							flex-grow: 1;
						}
						}
	
	@media only screen and (max-width: 767px){
						.music-style label {	
							width: 30%;
							flex-grow: 1;
						}
	}
</style>
       <div class="custom-container">
            <div class="form-container">
                <form action="#generate-track" method="GET" >

          
        
                    <h2 class="music-heading">Choose Music Style</h2>
                    <div class="music-style">
                            <?php

$style_terms = get_terms(array(
    'taxonomy' => 'music-style',
    'hide_empty' => false,
));


if (!empty($style_terms) && !is_wp_error($style_terms)) {
    
    foreach ($style_terms as $term) { ?>
        <label for="<?php echo $term->name; ?>"> <input type="radio" id="<?php echo $term->name; ?>" name="music_style" value="<?php echo $term->name; ?>"><?php echo $term->name; ?></label>
       <?php
    }
    
} else {
    echo 'No categories found.';
}




                        
                            $audio_src=NULL;
                            $the_query = new WP_Query(array(
                                                    'post_type' => 'music', 
                                                    'post_status'=>'publish',
                                                    'posts_per_page' => -1, 
                                                ));

                            $styles  = array();
                            $tempo  = array();
	   
                         

                            if($the_query->have_posts()){
                                while ($the_query->have_posts()):$the_query->the_post(); 
                                
                                $metadata=get_post_meta( get_the_id());
                            
                            $styles[] = $metadata['music_style'][0];
                            $tempo[] = $metadata['music_tempo'][0];
                            $files[]= $metadata['upload_music'][0];
                                            
                            endwhile;
                            }
                     
                                
                                ?>
                            
                    </div>
                    <h2 class="music-heading" id="generate-track">Choose Tempo</h2>
                    <div class="music-style">
                        <?php

$tempo_terms = get_terms(array(
    'taxonomy' => 'tempo',
    'hide_empty' => false,
));


if (!empty($tempo_terms) && !is_wp_error($tempo_terms)) {
    
    foreach ($tempo_terms as $term) { ?>
        <label for="<?php echo $term->name; ?>"> <input type="radio" id="<?php echo $term->name; ?>" name="music_tempo" value="<?php echo $term->name; ?>"><?php echo $term->name; ?></label>
       <?php
    }
    
} else {
    echo 'No categories found.';
}
                     
                            
                            ?>

                    </div>
                    <div class="gene-btn-area">
                        <input class="generate-btn" type="submit" name="submit" value="Generate Track">
                    </div>
        
                </form>

        
            </div>

            <?php

                    if(isset($_GET['submit'])){

                        $tracks = array();
                        $mstyle=NULL;
                        $mtempo=NULL;

                        if(isset($_GET['music_style'])){
                            $mstyle = $_GET['music_style'];
                        }

                        if(isset($_GET['music_tempo'])){
                            $mtempo = $_GET['music_tempo'];
                        }


                        if($the_query->have_posts()){
                            while ($the_query->have_posts()):$the_query->the_post(); 
                            
                            $style_terms_of_track=wp_get_post_terms(get_the_id(), 'music-style');
                            $tempo_terms_of_track=wp_get_post_terms(get_the_id(), 'tempo');
                            

                            if($mstyle && $mtempo){
                                
                                
                                
                                foreach ($style_terms_of_track as $style_track) {

                                if( $style_track->name==$mstyle){
                                     

                                   foreach ($tempo_terms_of_track as $tempo_track) {
										   if( $tempo_track->name==$mtempo){

			                                    $post_id = get_the_id();

										 		$tracks[]= $post_id;
                                			 }
									   
								   }
                                }
                                }
                                

                        } elseif($mstyle){
								
								  
                                foreach ($style_terms_of_track as $style_track) {

                                if( $style_track->name==$mstyle){
                                     

                                     
                                     $post_id = get_the_id();

                                      $tracks[]= $post_id;

                                }
                                }
								
						} elseif($mtempo){
								
								  
                               foreach ($tempo_terms_of_track as $tempo_track) {
										   if( $tempo_track->name==$mtempo){


			                                    $post_id = get_the_id();

										 		$tracks[]= $post_id;
                                			 }
									   
								   }
							}
                        

                                        
                        endwhile;
                        }

                        
            if(!empty($tracks)){

            $randtrack = $tracks[array_rand($tracks)];



            $audio_src = $randtrack;

            }else{

                echo "<h2 style='color:red; text-align:center;'>No music track found!</h2>";
            }
                        

                        


            };
     if(!empty($audio_src)){

	   			$title= get_post($audio_src)->post_title;
		 		$music_file_info = get_field("upload_music", $audio_src);
		 		$file_name = basename($music_file_info);
		 

	  			$image_url = wp_get_attachment_url( get_post_thumbnail_id($audio_src) ); 
		 		
		 		$meta_info=get_post_meta( $audio_src );

            ?>

                    <style>

                    html { box-sizing: border-box; }
                    *, *::before, *::after { box-sizing: inherit; }

                    .player-area {
                    /* display: flex;
                    justify-content: center;
                    align-items: center;
                    height: 150px;
                    color: #666; */
                    /* padding: 10px; */
                    /* font-size: 100%;
                    font-weight: 300; */
                    font-family: 'Roboto Condensed', sans-serif;
                    /* background-color: #222; */
                    
                    }

                    h1 {
                    margin-bottom: 0.5em;
                    font-weight: 400;
                    }

/*                     h2 { font-size: 87.5%; } */

                    .player {
                    display: flex;
                    position: relative;
                    width: 100%;
                    min-height: 100%;
                    overflow: hidden;
/*                     background-color: #eee; */
/* 					background: linear-gradient(to right, #fe0295, #2575fc) padding-box, linear-gradient(to right, #fe0295, #2575fc) border-box; */
						background: linear-gradient(45deg, rgba(255,3,147,1) 0%, rgba(171,2,194,1) 100%);
						color:#fff;
                    border-radius: 10px;
                    justify-content: space-between;
                    align-items: center;
                    padding:20px 10px;
                    
                    box-shadow:
                        0 1.5em 2em -1em rgba(0,0,0,0.8),
                        inset 0 0.0625em 0 rgba(255,255,255,1),
                        inset 0 -0.125em 0.0625em rgba(0,0,0,0.3);
                    }

                    .album {
                    position: relative;
                    left: 10px;
                    top:50%;
                    width: 150px;
                    height: 150px;
                    padding: 22px;
                    /* margin-bottom: -13%; */
                    overflow: hidden;
                    /* transform: translate(-50%, -50%); */
                    background-color: #111;
                    border: 1px solid #111;
                    border-radius: 50%;
                    box-shadow:
                        0 0.0625em 0.1875em rgba(0,0,0,0.5),
                        0 0 0.125em 0.3125em #ddd,
                        0 0.0625em 0 0.375em #bbb,
                        0 0 0.375em 0.325em rgba(0,0,0,0.3),
                        0 0 0.5em 0.375em rgba(0,0,0,0.3),
                        0 0.25em 1em 0.5em rgba(0,0,0,0.15),
                        inset 0 0 0 0.0625em rgba(0,0,0,0.5),
                        inset 0 0 0 0.1875em rgba(255,255,255,1),
                        inset 0 0 0 0.375em rgba(0,0,0,0.5),
                        inset 0 0 0 0.4375em rgba(255,255,255,0.2),
                        inset 0 0 0 0.5em rgba(0,0,0,0.5),
                        inset 0 0 0 0.5625em rgba(255,255,255,0.3),
                        inset 0 0 0 0.625em rgba(0,0,0,0.5),
                        inset 0 0 0 0.6875em rgba(255,255,255,0.2),
                        inset 0 0 0 0.75em rgba(0,0,0,0.5),
                        inset 0 0 0 0.8125em rgba(255,255,255,0.3),
                        inset 0 0 0 0.875em rgba(0,0,0,0.5),
                        inset 0 0 0 0.9375em rgba(255,255,255,0.3),
                        inset 0 0 0 1em rgba(0,0,0,0.5),
                        inset 0 0 0 1.0625em rgba(255,255,255,0.2),
                        inset 0 0 0 1.125em rgba(0,0,0,0.5),
                        inset 0 0 0 1.1875em rgba(255,255,255,0.3),
                        inset 0 0 0 1.25em rgba(0,0,0,0.5),
                        inset 0 0 0 1.3125em rgba(255,255,255,0.2),
                        inset 0 0 0 1.375em rgba(255,255,255,0.2),
                        inset 0 0 0 1.4375em rgba(0,0,0,0.5),
                        inset 0 0 0 1.5em rgba(255,255,255,0.3),
                        inset 0 0 0 1.5625em rgba(0,0,0,0.5),
                        inset 0 0 0 1.625em rgba(255,255,255,0.3),
                        inset 0 0 0 1.6875em rgba(0,0,0,0.5),
                        inset 0 0 0 1.75em rgba(255,255,255,0.2),
                        inset 0 0 0 1.8125em rgba(0,0,0,0.5),
                        inset 0 0 0 1.875em rgba(255,255,255,0.2),
                        inset 0 0 0 1.9375em rgba(0,0,0,0.5),
                        inset 0 0 0 2em rgba(255,255,255,0.3),
                        inset 0 0 0 2.0625em rgba(0,0,0,0.5),
                        inset 0 0 0 2.125em rgba(0,0,0,0.5),
                        inset 0 0 0 2.1875em rgba(255,255,255,0.1),
                        inset 0 0 0 2.25em rgba(0,0,0,0.5),
                        inset 0 0 0 2.3125em rgba(255,255,255,0.2),
                        inset 0 0 0 2.375em rgba(255,255,255,0.1),
                        inset 0 0 0 2.4375em rgba(0,0,0,0.5),
                        inset 0 0 0 2.5em rgba(255,255,255,0.3),
                        inset 0 0 0 2.5625em rgba(0,0,0,0.5),
                        inset 0 0 0 2.625em rgba(255,255,255,0.2),
                        inset 0 0 0 2.6875em rgba(0,0,0,0.5),
                        inset 0 0 0 2.75em rgba(255,255,255,0.2),
                        inset 0 0 0 2.8125em rgba(0,0,0,0.5),
                        inset 0 0 0 2.875em rgba(255,255,255,0.2),
                        inset 0 0 0 2.9375em rgba(0,0,0,0.5),
                        inset 0 0 0 3em rgba(255,255,255,0.3),
                        inset 0 0 0 3.0625em rgba(0,0,0,0.5),
                        inset 0 0 0 3.125em rgba(0,0,0,0.5),
                        inset 0 0 0 3.1875em rgba(255,255,255,0.2),
                        inset 0 0 0 3.25em rgba(0,0,0,0.5),
                        inset 0 0 0 3.3125em rgba(255,255,255,0.2),
                        inset 0 0 0 3.375em rgba(255,255,255,0.1),
                        inset 0 0 0 3.4375em rgba(0,0,0,0.5),
                        inset 0 0 0 3.5em rgba(255,255,255,0.3);
                    }

                    .album::after {
                    content: '';
                    position: absolute;
                    top: 50%;
                    left: 50%;
                    width: 100%;
                    height: 100%;
                    transform: translate(-50%,-50%);
                    background-image:
                        linear-gradient(
                        -45deg,
                        rgba(255,255,255,0) 30%,
                        rgba(255,255,255,0.125),
                        rgba(255,255,255,0) 70%
                        ),
                        linear-gradient(
                        -48deg,
                        rgba(255,255,255,0) 45%,
                        rgba(255,255,255,0.075),
                        rgba(255,255,255,0) 55%
                        ),
                        linear-gradient(
                        -42deg,
                        rgba(255,255,255,0) 45%,
                        rgba(255,255,255,0.075),
                        rgba(255,255,255,0) 55%
                        ),
                        radial-gradient(
                        circle at top left,
                        rgba(0,0,0,1) 20%,
                        rgba(0,0,0,0) 80%
                        ),
                        radial-gradient(
                        circle at bottom right,
                        rgba(0,0,0,1) 20%,
                        rgba(0,0,0,0) 80%
                        );
                    }
						
						.right-side-pr {
							display: flex;
							width: 100%;
						
							justify-content: space-around;
							align-items: center;
						}

                    .left-side{
                        display:block;
                        width: 20%;
                        /* background: red; */
                    }
                    .right-side{
                        /* background:blue; */
                        width:70%;
                        padding: 0 10px;
                        display: flex; 
                        flex-direction: column; 
                        justify-content: space-evenly;
                    }
						
						.middle-side {
    						width: 15%;
							text-align:right;
						}
						.last-side {
							width: 15%;
							text-align: left;
						}
						
                    .cover,
                    .cover div {
                    position: absolute;
                    z-index: 1;
                    top: 50%;
                    left: 50%;
                    width: 6em;
                    height: 6em;
                    overflow: hidden;
                    transform-origin: 0 0;
                    transform: rotate(0) translate(-50%,-50%);
                    border-radius: 50%;
                    animation: spin 4s linear infinite paused;
                    }

                    .ffing .cover {
                    animation-play-state: running;
                    }

                    .cover div {
                    border-radius: 0;
                    animation: spin 2s linear infinite reverse paused;
                    }

                    .rwing .cover div {
                    animation: spin 2s linear infinite reverse running;
                    }

                    .cover::before,
                    .cover::after {
                    content: '';
                    position: absolute;
                    z-index: 10;
                    top: 50%;
                    left: 50%;
                    width: 100%;
                    height: 100%;
                    transform-origin: 0 0;
                    transform: rotate(0) translate(-50%,-50%);
                    border-radius: 50%;
                    box-shadow: inset 0 0.0625em rgba(255,255,255,0.3);
                    animation: spin 4s linear infinite reverse paused;
                    }

                    .cover::after {
                    width: 0.25em;
                    height: 0.3125em;
                    margin-top: -0.0625em;
                    background-color: #eee;
                    border-radius: 0.125em;
                    box-shadow:
                        inset 0 -0.0625em 0.0625em rgba(0,0,0,0.5),
                        inset 0.0625em -0.0625em 0.125em rgba(255,255,255,0.15),
                        inset -0.0625em -0.0625em 0.125em rgba(255,255,255,0.15),
                        inset 0 -0.125em 0.125em rgba(0,0,0,0.8),
                        0 0.0625em 0.0625em rgba(0,0,0,0.5),
                        0 0.0625em 0.25em 0.0625em rgba(0,0,0,0.15),
                        0 0 0.25em 0.125em rgba(0,0,0,0.15);
                    }

                    .ffing .cover::before,
                    .ffing .cover::after {
                    animation-play-state: running;
                    }

                    .cover img {
                    position: absolute;
                    top: 50%;
                    left: 50%;
                    width: 100%;
                    height: 100%;
                    transform-origin: 0 0;
                    transform: rotate(0) translate(-50%,-50%);
                    animation: spin 4s linear infinite paused;
                    }

                    .paused .cover img {
                    animation-play-state: paused;
                    }

                    .playing .cover img {
                    animation-play-state: running;
                    }

                    .info {
                    height: 150px;
					display: flex;
					text-align: center;
					flex-direction: column;
					flex-wrap: nowrap;
					align-content: center;
					justify-content: space-between;
                    }
						
                    .info h3{
                        display: flex;
						font-size: 16px;
						color: #fff;
						margin-top: 0;
						
						flex-direction: column;
						flex-wrap: nowrap;
						align-content: center;
						justify-content: center;
                    }
						
                    .time {
                   	height: 40px;
					margin-top: 0;
					display: flex;
					justify-content: center;
					align-items: center;
					padding: 0 0.5em;
					margin-bottom: 0;
					color: #fff;
                    }

                    .time > * {
                    margin: 0 0.5em;
                    }

                    .progress {
                    flex-grow: 2;
                    height: 8px;
                    background: #fff;
                    border-radius: 50px;
                    cursor: pointer;
                    }

                    .progress span {
                    display: block;
                    width: 0;
                    height: 100%;
                    background: #000;
					border-radius:50px;
                    }

                    .actions {
                    position: relative;
                    width: 100%;
                    padding: 1em 0 1.125em;
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    justify-content:space-around;
                    }

                    button {
                    appearance: none;
                    outline: none;
                    position: relative;
                    padding: 0;
                    font-size: 100%;
                    background-color: #f4f4f4 !important;
                    border: none;
                    cursor: pointer;
                    
                    }

                    .button {
                    width: 3em;
                    height: 3em;
                    /* background-color: transparent;
                    background-image: linear-gradient(#ddd, #f6f6f6); */
/*                     background: linear-gradient(180deg, rgba(163,76,169,1) 0%, rgba(249,3,146,1) 100%); */
                    border: none;
                    border-radius: 50%;
                    }
						
					i.fa-solid.fa-download {
						position: absolute;
						z-index: 10;
						top: 50%;
						left: 50%;
						width: 30%;
						height: 30%;
						overflow: hidden;
						transform: translate(-50%,-50%);
						font-size:15px;
					}
						
						.last-side .button{
							width: 64px !important;
							height: 64px !important;
							/* background: linear-gradient(180deg, rgba(163,76,169,1) 0%, rgba(249,3,146,1) 100%); */
							border: none;
							border-radius: 50%;
						}
						
						.last-side .button:hover{
							background:#f00abb !important;
						}
						
					
                    .button::before {
                    content: '';
                    position: absolute;
                    z-index: 1;
                    top: 50%;
                    left: 50%;
                    width: 80%;
                    height: 80%;
                    transform: translate(-50%,-50%);
                    background-color: #f4f4f4;
                    border: 0.125em solid #d5d5d5;
                    border-radius: 50%;
                    box-shadow: inset 0 0.25em 1em -0.25em rgba(255,255,255,0.75);
                    }

                    .button:hover::before {
                    background-color: #fcfcfc;
/*                     background: linear-gradient(180deg, rgba(163,76,169,1) 0%, rgba(249,3,146,1) 100%); */
                    }
					
						.buttin a i{
							color:red !important;
							font-size:30px;
							
						}
                    .play-pause {
                    width: 4em;
                    height: 4em;
                    }

                    .rw {
                    right: -0.25em;
                    margin-left: 0.375em;
                    transform: scaleX(-1);
                    width: 4em;
                    height: 4em;
                    }

                    .ff {
                    left: -0.25em;
                    margin-right: 0.375em;
                    width: 4em;
                    height: 4em;
                    }

                    .button .arrow {
                    position: absolute;
                    z-index: 10;
                    top: 50%;
                    left: 50%;
                    width: 30%;
                    height: 30%;
                    overflow: hidden;
                    transform: translate(-50%,-50%);
                    }

                    .button .arrow::before,
                    .button .arrow::after {
                    content: '';
                    position: absolute;
                    left: -50%;
                    width: 100%;
                    height: 100%;
                    transform: scale(1.2,0.7) rotate(45deg);
                    background-color: #f00abb;
                    box-shadow:
                        inset 0 0.125em 0.125em -0.0625em rgba(0,0,0,0.15),
                        0.0625em 0.0625em 0.125em rgba(255,255,255,1);
                    }

                    .button .arrow::after {
                    left: 0;
                    transform: none;
                    background-color: transparent;
                    box-shadow: inset 0.0625em 0 0.125em -0.0625em rgba(0,0,0,0.1);
                    }

						
                    .paused .play-pause .arrow {
                    margin-left: 0.1875em;
                    }

                    .playing .play-pause .arrow::before,
                    .playing .play-pause .arrow::after {
                    left: 0;
                    width: 0.4375em;
                    transform: none;
/*                     background-color: #ddd; */
					background-color: #f00abb !important;
                    box-shadow:
                        inset 0.0625em 0.125em 0.125em -0.0625em rgba(0,0,0,0.15),
                        0.0625em 0.0625em 0.125em rgba(255,255,255,1);
                    }

                    .playing .play-pause .arrow::after {
                    left: auto;
                    right: 0;
                    }

                    .rw .arrow,
                    .ff .arrow {
                    width: 20%;
                    height: 20%;
                    margin-left: 12%;
                    }

                    .rw .arrow:first-child,
                    .ff .arrow:first-child {
                    margin-left: -4%;
                    }

                    .button:active .arrow::before,
                    .playing .play-pause .arrow::before,
                    .playing .play-pause .arrow::after {
                    background-color: #cef;
                    }

                    .shuffle {
                    width: 1.375em;
                    height: 1.375em;
                    color: #d5d5d5;
                    }

                    .shuffle .arrow {
                    position: absolute;
                    top: 0.1875em;
                    left: 0;
                    width: 0.375em;
                    height: 0.125em;
                    color: inherit;
                    background-color: currentColor;
                    }

                    .shuffle .arrow::before {
                    content: '';
                    position: absolute;
                    top: 0;
                    left: calc(100% + 0.125em);
                    width: 0.5em;
                    height: 1em;
                    transform: skewX(30deg);
                    border-bottom: 0.125em solid;
                    border-left: 0.125em solid;
                    box-shadow:
                        -0.3125em 0em 0 -0.1875em #eee,
                        inset 0.375em 0.25em 0 -0.25em #eee;
                    }

                    .shuffle .arrow::after {
                    content: '';
                    position: absolute;
                    top: 0.6875em;
                    left: calc(100% + 0.625em);
                    border: 0.25em solid transparent;
                    border-left-width: 0.375em;
                    border-left-color: currentColor;
                    }

                    .shuffle .arrow:first-child {
                    transform-origin: 0 0.5em;
                    transform: scaleY(-1);
                    }

                    .repeat {
                    width: 1.375em;
                    height: 1.375em;
                    color: #d5d5d5;
                    border: 0.125em solid;
                    border-right-color: transparent;
                    border-radius: 50%;
                    }

                    .repeat::before {
                    content: '';
                    position: absolute;
                    top: -0.125em;
                    left: -0.125em;
                    width: calc(100% + 0.25em);
                    height: calc(100% + 0.25em);
                    transform: rotate(-45deg);
                    border: 0.125em solid transparent;
                    border-right-color: currentColor;
                    border-radius: 50%;
                    }

                    .repeat::after {
                    content: '';
                    position: absolute;
                    top: 50%;
                    right: -0.3125em;
                    border: 0.25em solid transparent;
                    border-top-width: 0.375em;
                    border-top-color: currentColor;
                    }

                    .shuffle.active,
                    .repeat.active {
                    color: #bde;
                    }
						
						.info-area{
							display:flex;
							height:40px;
							justify-content: space-between;
    						flex-wrap: wrap;
						}
						
						
						.title-area {
							width: 50%;
							text-align: left;
							display: flex;
						}
						
						.title-area marquee {
							margin-left: 5px;
						}
					
						.others-info {
							width: 50%;
							text-align: right;
/* 							display: flex;
							flex-wrap: nowrap;
							justify-content: space-around; */
						}
					
						.others-info h3 {
						
							display: inline-block;
							color: #fff;
							padding: 1px 5px 0 5px;
							border-radius: 5px;
							font-size: 14px;
							border: 1.5px solid #fff;
							margin-left:5px;
						}
					
						.others-info .source-title {
						
							display: inline-block;
							color: #fff;
							padding: 0px 10px;
							border-radius: 5px;
							font-size: 14px;
							border: 1px solid transparent;
						}
						
						.others-info-mobile {
							display: none;
							width: 100%;
							text-align: center;
						}
						
						.others-info-mobile-mini{
							display:none !important;
						}
						
                    /* wave css  start*/

                    .wave-area {
                        /* background: #1b1c1c; */
                        height: 50px;
						display: grid;
						place-items: center;
						overflow: hidden;
						padding: 0 16px;
						width: 100%;
                    }
                    .wave-area .sound-wave {
                        height: 50px;
                        display: flex;
                        align-items: center;
                        justify-content: space-between;
                        width: 100%;
                    }
                    .wave-area .bar {
                        animation-name: wave-lg;
                        animation-iteration-count: infinite;
                        animation-timing-function: ease-in-out;
                        animation-direction: alternate;
                        background: #fff;
                        margin: 0 1.5px;
                        height: 10px;
                        width: 1px;
                    }
                    .wave-area .bar:nth-child(-n + 7), .wave-area .bar:nth-last-child(-n + 7) {
                        animation-name: wave-md;
                    }
                    .wave-area .bar:nth-child(-n + 3), .wave-area .bar:nth-last-child(-n + 3) {
                        animation-name: wave-sm;
                    }
                    @keyframes wave-sm {
                        0% {
                            opacity: 0.35;
                            height: 10px;
                        }
                        100% {
                            opacity: 1;
                            height: 15px;
                        }
                    }
                    @keyframes wave-md {
                        0% {
                            opacity: 0.35;
                            height: 5px;
                        }
                        100% {
                            opacity: 1;
                            height: 20px;
                        }
                    }
                    @keyframes wave-lg {
                        0% {
                            opacity: 0.35;
                            height: 5px;
                        }
                        100% {
                            opacity: 1;
                            height: 35px;
                        }
                    }
                    
                    /* wave css end */





                    @keyframes spin {
                    100% { transform: rotate(360deg) translate(-50%,-50%); }
                    }
						
					 @media only screen and (max-width: 1359px){
						 .others-info{
							 display:none;
						 }
						 .others-info-mobile{
							 display:block;
						 }
						 
						 .title-area{
							 width:100%; 
							 text-align:center;
						 }
                    }

                    @media only screen and (max-width: 1100px){
                        .left-side{
                            width: 25%;
                        }
                        .right-side-pr{
                            width: 75%;
                            padding:0;
                        }
                    }
						
                    @media only screen and (max-width: 1024px){


                        .album {
                            width: 125px;
                            height: 125px;
                        }
						
						.sound-wave{
							margin-top:5px;
						}
						
						
					
						
						
                     
                    }
					
					
						
                    @media only screen and (max-width: 767px){
						
						.player{
							flex-direction:column;
						}
						
						
                      .left-side {
						width: 100%;
						display: flex;
						justify-content: center;
						}
						
					  .right-side-pr{
                            width: 100%;
                            padding:0;
                        }
						
						.album{
							left:0;
						}
						
						
						.middle-side {
    						width: 20%;
						}
						.last-side {
							width: 20%;
							
						}
						.right-side{
							width:60%;
						}
                        
						.wave-area {
							justify-content: center;
						}
						
						.info-area{
							margin-top:10px;
						}
                       
                    }
						 @media only screen and (max-width: 668px){
                         
							 
                        
                    }
						
                    @media only screen and (max-width: 600px){
						
						.player-area{
							margin-bottom:250px !important;
						}

						.info-area{
							padding-top:5px;	
						}
						
						 .title-area{
							font-size:12px;
						 }
						 .others-info h3{
							font-size:12px;
						 }
						
						.others-info-mobile h3 {
							font-size: 12px;
							padding: 3px;
							justify-content: flex-start;
							align-content: center;
							display: inline;
						}
						
						.others-info-mobile{
							display:none;
						}
						
						.others-info-mobile-mini{
							display:block !important;
						}
						
						.sound-wave{
							margin-top:-3px;
						}
						
                        
                    }
                    @media only screen and (max-width: 425px){
 
                
                        .right-side{
/*                           padding-top:10px; */
                        }  
						
						.middle-side,
						.last-side{
							padding-top:17px;
						}

                        .time{
                            padding:0;
                        }
                   
                        .info h3 {
                        font-size: 12px;
                        margin-top: 12px;
                        margin-bottom: 5px;
                        }

                        .album {
                            width: 100px;
                            height: 100px;
                        }

/*                         .actions{
                            padding:0;
                        }
						 */
                        .button {
                            width: 3em;
                            height: 3em;
                            padding:15px !important;
							margin-right: 5px;
                        
                        }
						
						.last-side .button {
							width: 3em !important;
							height: 3em!important;
						}
                    
                    }
                            
                    </style>

                <div class="player-area">

                    <!-- ************************ -->

            
                        <div class="player paused">
                            <div class="left-side">
                                <div class="album">
                                    <div class="cover">
										
										
                                        <div><img src="<?php echo "https://ostinat.com/wp-content/uploads/2024/06/Logo-Ostinat.png"; ?>" alt="<?php echo  $title; ?>" /></div>
                                    </div>
                                </div>
								
														
                            </div>
							
							<div class="right-side-pr">
								
								<div class="middle-side">
									  <button class="button play-pause">
											<div class="arrow"></div>
									  </button>
								</div>
								<div class="right-side">
									<div class="info">

												<div class="info-area">
													<div class="title-area">
														<h3>Track:</h3>
														<h3><marquee behavior="scroll" direction="left" scrollamount="7"><?php echo $file_name; ?></marquee></h3>
													</div>
													<div class="others-info">
														<h3 class="source-title">
															Source:
														</h3> 
														<?php
														if($mstyle){ ?>
															<h3><?php echo $mstyle; ?></h3>
														<?php
														} 
														if($mtempo){ ?>
															<h3><?php echo $mtempo; ?></h3>
														<?php
														} ?>
														
													</div>
														
														
												</div>
										
												<div class="wave-area">
													<div class='sound-wave'>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
														<div class='bar'></div>
													</div>
												</div>
												<div class="time">
												<span class="current-time">0:00</span>
												<span class="progress"><span></span></span>
												<!-- <span class="duration">0:00</span> -->
												</div>
										
												<div class="others-info-mobile others-info">
														<h3 class="source-title">
															Source:
														</h3>
														<?php
														if($mstyle){ ?>
															<h3><?php echo $mstyle; ?></h3>
														<?php
														} 
														if($mtempo){ ?>
															<h3><?php echo $mtempo; ?></h3>
														<?php
														} ?>
												</div>
									</div>

	<!--                                 <div class="actions"> -->
										<!-- <button class="shuffle">
										<div class="arrow"></div>
										<div class="arrow"></div>
										</button> -->
	<!--                                     <button class="button rw">
										<div class="arrow"></div>
										<div class="arrow"></div>
										</button> -->
	<!--                                     <button class="button play-pause">
										<div class="arrow"></div>
										</button> -->
	<!--                                     <button class="button ff">
										<div class="arrow"></div>
										<div class="arrow"></div>
										</button> -->




										<!-- <button class="repeat"></button> -->
	<!--                                 </div> -->
									<audio id="current_player" prelaod src="<?php echo $music_file_info; ?>"></audio>

								</div>
								<div class="last-side">
									<button class="button">
									   <a href="<?php echo $music_file_info; ?>" download="<?php echo $music_file_info; ?>">
										<i class="fa-solid fa-download"></i>
										</a>
										</button>

								</div>
            
           					</div>
							<div class="others-info-mobile-mini others-info-mobile others-info">
														<h3 class="source-title">
															Source:
														</h3>
														<h3><?php echo $meta_info['music_style'][0]; ?></h3>
														<h3><?php echo $meta_info['music_tempo'][0]; ?></h3>
							</div>
                   
                </div>

    </div>
    <?php
      }
    ?>
</div>

      
      <?php
       return ob_get_clean();
   }

}

if (class_exists('Kmaa_Audio_Filter')) {
   $audiofilter = new Kmaa_Audio_Filter();
   $audiofilter->shortcode();
   
   

  

}
